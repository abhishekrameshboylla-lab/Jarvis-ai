package com.example.jarvis

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.speech.RecognizerIntent
import android.speech.tts.TextToSpeech
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : Activity(), TextToSpeech.OnInitListener {
    private lateinit var speech: TextToSpeech
    private lateinit var status: TextView
    private lateinit var transcript: TextView
    private lateinit var taskInput: EditText
    private lateinit var taskList: TextView
    private var ttsReady = false
    private val tasks = mutableListOf<String>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        speech = TextToSpeech(this, this)

        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 28, 28, 28)
            setBackgroundColor(0xFF07111F.toInt())
        }
        val scroll = ScrollView(this)
        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, 0, 0, 24)
        }

        fun label(text: String, size: Float, color: Int = 0xFFEAF4FF.toInt()): TextView =
            TextView(this).apply {
                this.text = text
                textSize = size
                setTextColor(color)
                setPadding(0, 10, 0, 10)
            }

        fun button(text: String, action: () -> Unit): Button =
            Button(this).apply {
                this.text = text
                isAllCaps = false
                setOnClickListener { action() }
            }

        content.addView(label("J.A.R.V.I.S.", 30f, 0xFF65D8FF.toInt()))
        content.addView(label("PERSONAL AI • TABLET EDITION", 12f, 0xFF9DB5CC.toInt()))
        status = label("SYSTEM STATUS: READY", 16f, 0xFF7CFFB2.toInt())
        content.addView(status)
        content.addView(button("🎙  Talk to JARVIS") { startListening() })
        transcript = label("JARVIS: Online. Tap Talk to give a voice command.", 16f)
        content.addView(transcript)
        content.addView(button("System status") {
            respond("Basic JARVIS demo is running. Voice and housekeeping demo features are available.")
        })
        content.addView(button("Security dashboard") {
            respond("Security module is a starter placeholder. This app does not scan the whole Android device.")
        })
        content.addView(button("Encryption center") {
            respond("Encryption center is not enabled in this starter build. Do not use this demo to protect sensitive files yet.")
        })
        content.addView(label("HOUSEKEEPING TASKS", 18f, 0xFF65D8FF.toInt()))
        taskInput = EditText(this).apply {
            hint = "Enter a task or reminder"
            setHintTextColor(0xFF8294A8.toInt())
            setTextColor(0xFFFFFFFF.toInt())
            setSingleLine(true)
        }
        content.addView(taskInput, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
        ))
        content.addView(button("Add task") { addTask() })
        taskList = label("No tasks added yet.", 15f)
        content.addView(taskList)
        content.addView(label(
            "Privacy note: This starter does not connect to an online AI service. API keys should never be embedded directly in an Android app.",
            12f, 0xFF9DB5CC.toInt()
        ))

        scroll.addView(content)
        page.addView(scroll, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f
        ))
        setContentView(page)
    }

    private fun startListening() {
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.US.toLanguageTag())
            putExtra(RecognizerIntent.EXTRA_PROMPT, "Speak to JARVIS in English")
        }
        try {
            startActivityForResult(intent, REQUEST_SPEECH)
        } catch (_: Exception) {
            respond("Speech recognition is not available on this device right now.")
        }
    }

    @Deprecated("Deprecated by Android API, kept for broad device compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQUEST_SPEECH && resultCode == RESULT_OK) {
            val spoken = data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
            if (!spoken.isNullOrBlank()) handleCommand(spoken)
        }
    }

    private fun handleCommand(command: String) {
        val normalized = command.lowercase(Locale.US)
        when {
            "time" in normalized || "date" in normalized -> {
                val now = SimpleDateFormat("EEEE, MMMM d, yyyy 'at' h:mm a", Locale.US).format(Date())
                respond("The current date and time is $now.")
            }
            "security" in normalized -> respond("Security dashboard selected. This demo only shows app-level status and cannot inspect all Android system activity.")
            "encrypt" in normalized || "encryption" in normalized ->
                respond("Encryption center selected. File encryption is not implemented in this starter build.")
            "task" in normalized || "reminder" in normalized || "housekeeping" in normalized ->
                respond("Housekeeping is ready. Enter a task in the task field and tap Add task.")
            "status" in normalized || "online" in normalized ->
                respond("All demo components are responsive. Online AI and advanced security integrations are not connected yet.")
            else -> respond("I heard: $command. This starter supports time, date, status, security, encryption, and housekeeping commands. Online AI can be added in the next development step.")
        }
    }

    private fun addTask() {
        val task = taskInput.text.toString().trim()
        if (task.isEmpty()) {
            respond("Please enter a task first.")
            return
        }
        tasks.add(task)
        taskInput.setText("")
        taskList.text = tasks.mapIndexed { index, item -> "${index + 1}. $item" }.joinToString("\n")
        respond("Task added: $task.")
    }

    private fun respond(message: String) {
        transcript.text = "JARVIS: $message"
        if (ttsReady) speech.speak(message, TextToSpeech.QUEUE_FLUSH, null, "jarvis-response")
    }

    override fun onInit(statusCode: Int) {
        ttsReady = statusCode == TextToSpeech.SUCCESS
        if (ttsReady) speech.language = Locale.US
    }

    override fun onDestroy() {
        if (::speech.isInitialized) {
            speech.stop()
            speech.shutdown()
        }
        super.onDestroy()
    }

    companion object {
        private const val REQUEST_SPEECH = 101
    }
}
